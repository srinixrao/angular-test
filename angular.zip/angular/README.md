# Bank of America - GitHub Test Code

I have implemented the responsive web design aspects and some of the UXM related media queries.

I have implemented with PHP as server lang.

