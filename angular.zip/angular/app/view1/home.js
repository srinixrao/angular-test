'use strict';

angular.module('myApp.view1', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/home', {
    templateUrl: 'view1/home.html',
    controller: 'View1Ctrl'
  });
}])

.controller('View1Ctrl', ['$scope','$http', function($scope, $http) {

	$http({
	  method: 'GET',
	  url: '../get-receipe.php'
	}).then(function successCallback(response) {
		//alert(response);
	   	$scope.receipeList = response.data.recipes;
	   	console.log(response.data.recipes);
	  }, function errorCallback(response) {
	    // called asynchronously if an error occurs
	    // or server returns response with an error status.
	  });
}]);